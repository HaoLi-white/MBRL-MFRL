import random
import gym
import numpy as np
import pandas as pd
from tqdm import tqdm
import torch
import torch.nn.functional as F
from torch.distributions import Normal
import matplotlib.pyplot as plt
import rl_utils
from env import *
from datetime import datetime


class PolicyNetContinuous(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, action_dim, action_bound):
        super(PolicyNetContinuous, self).__init__()
        self.fc1 = torch.nn.Linear(state_dim, hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.fc4 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.fc_mu = torch.nn.Linear(hidden_dim, action_dim)
        self.fc_std = torch.nn.Linear(hidden_dim, action_dim)
        self.action_bound = action_bound

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        x = F.relu(self.fc4(x))
        mu =self.fc_mu(x)
        # print(mu)
        # mu =F.softplus(self.fc_mu(x)+1e-7)
        # mu = torch.tanh(mu)
        # mu = mu * 0.5+0.5
        # print(mu)
        std = F.softplus(self.fc_std(x))+1e-7
        dist = Normal(mu, std)
        # print(dist)
        normal_sample = dist.rsample()
        log_prob = dist.log_prob(normal_sample)
        action = torch.tanh(normal_sample)
        log_prob = log_prob - torch.log(1 - torch.tanh(action).pow(2) + 1e-7)
        action = action * self.action_bound
        action = 0.5*action+0.5
        # print(action)
        return action, log_prob

class QValueNetContinuous(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, action_dim):
        super(QValueNetContinuous, self).__init__()
        self.fc1 = torch.nn.Linear(state_dim + action_dim, hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.fc_out = torch.nn.Linear(hidden_dim, 3)


    def forward(self, x, a):
        cat = torch.cat([x, a], dim=1)
        x = F.relu(self.fc1(cat))
        x = F.relu(self.fc2(x))
        return self.fc_out(x)



class SACContinuous:
    ''' 处理连续动作的SAC算法 '''
    def __init__(self, state_dim, hidden_dim, action_dim, action_bound,
                 actor_lr, critic_lr, alpha_lr, target_entropy, tau, gamma,
                 device):
        self.actor = PolicyNetContinuous(state_dim, hidden_dim, action_dim,
                                         action_bound).to(device)  # 策略网络
        self.critic_1 = QValueNetContinuous(state_dim, hidden_dim,
                                            action_dim).to(device)  # 第一个Q网络
        self.critic_2 = QValueNetContinuous(state_dim, hidden_dim,
                                            action_dim).to(device)  # 第二个Q网络
        self.target_critic_1 = QValueNetContinuous(state_dim,
                                                   hidden_dim, action_dim).to(
                                                       device)  # 第一个目标Q网络
        self.target_critic_2 = QValueNetContinuous(state_dim,
                                                   hidden_dim, action_dim).to(
                                                       device)  # 第二个目标Q网络

        # 令目标Q网络的初始参数和Q网络一样
        self.target_critic_1.load_state_dict(self.critic_1.state_dict())
        self.target_critic_2.load_state_dict(self.critic_2.state_dict())
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(),
                                                lr=actor_lr)
        self.critic_1_optimizer = torch.optim.Adam(self.critic_1.parameters(),
                                                   lr=critic_lr)
        self.critic_2_optimizer = torch.optim.Adam(self.critic_2.parameters(),
                                                   lr=critic_lr)
        # 使用alpha的log值,可以使训练结果比较稳定
        self.log_alpha = torch.tensor(np.log(0.01), dtype=torch.float)
        self.log_alpha.requires_grad = True  # 可以对alpha求梯度
        self.log_alpha_optimizer = torch.optim.Adam([self.log_alpha],
                                                    lr=alpha_lr)
        self.target_entropy = target_entropy  # 目标熵的大小
        self.gamma = gamma
        self.tau = tau
        self.device = device

        # 用于动作限幅
        # self.action_bound = action_bound
        # self.action_len_ratio = (self.action_bound[1] - self.action_bound[0]) / 2  # 动作区间长度占-1~1长度的比率
        # self.action_bias = self.action_bound[0] + self.action_len_ratio  # 动作区间偏移量
        # self.std_bound = std_bound
    def take_action(self, state):
        state = np.array(state)  # 将numpy数组列表转换为单个numpy.ndarray
        state = torch.tensor(state, dtype=torch.float).to(self.device)  # 将numpy.ndarray转换为张量
        action = self.actor(state)[0]
        action=action.tolist()
        return action
    # def take_action(self, state):
    #     state = np.array(state, dtype=np.float32)
    #     state = torch.tensor(state, dtype=torch.float32).to(self.device)
    #     mu, std = self.actor(state)
    #     mu = mu * 0.5 + 0.5  # 将mu从-1~1映射到动作目标区间
    #     std = torch.clamp(std, 3e-5, 16e-3)
    #     nor_obj = Normal(mu, std)   # 得到1个torch.normal类，内含mu和std的原始线性输出值
    #     action = nor_obj.rsample()  # rsample()是重参数化采样，返回可导的tensor样本
    #     log_prob = nor_obj.log_prob(action)  # 采样结果丢进log_prob函数，计算对数概率密度，类型为tensor
    #     action = torch.clamp(action, 0, 1)  # 相当于tf的clip作范围裁剪
    #     action = action.tolist()
    #     return action, log_prob

    def calc_target(self, rewards, next_states, dones):  # 计算目标Q值
        next_actions, log_prob = self.actor(next_states)
        entropy = -log_prob
        q1_value = self.target_critic_1(next_states, next_actions)
        q2_value = self.target_critic_2(next_states, next_actions)
        next_value = torch.min(q1_value,q2_value) + self.log_alpha.exp() * entropy
        td_target = rewards + self.gamma * next_value * (1 - dones)
        # print(td_target)
        return td_target

    def soft_update(self, net, target_net):
        for param_target, param in zip(target_net.parameters(),
                                       net.parameters()):
            param_target.data.copy_(param_target.data * (1.0 - self.tau) +
                                    param.data * self.tau)

    def update(self, transition_dict):
        states = torch.tensor(transition_dict['states'],
                              dtype=torch.float).view(-1, 10).to(self.device)
        actions = torch.tensor(transition_dict['actions'],
                               dtype=torch.float).view(-1, 3).to(self.device)
        rewards = torch.tensor(transition_dict['rewards'],
                               dtype=torch.float).view(-1, 1).to(self.device)
        next_states = torch.tensor(transition_dict['next_states'],
                                   dtype=torch.float).view(-1, 10).to(self.device)
        dones = torch.tensor(transition_dict['dones'],
                             dtype=torch.float).view(-1, 1).to(self.device)

        # 更新策略网络
        new_actions, log_prob = self.actor(states)
        entropy = -log_prob
        q1_value = self.critic_1(states, new_actions)
        q2_value = self.critic_2(states, new_actions)
        actor_loss = torch.mean(-self.log_alpha.exp() * entropy -
                                torch.min(q1_value, q2_value))
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # 更新两个Q网络
        td_target = self.calc_target(rewards, next_states, dones)
        critic_1_loss = torch.mean(
            F.mse_loss(self.critic_1(states, actions), td_target.detach()))
        critic_2_loss = torch.mean(
            F.mse_loss(self.critic_2(states, actions), td_target.detach()))
        self.critic_1_optimizer.zero_grad()
        critic_1_loss.backward()
        self.critic_1_optimizer.step()
        self.critic_2_optimizer.zero_grad()
        critic_2_loss.backward()
        self.critic_2_optimizer.step()



        # 更新alpha值
        alpha_loss = torch.mean(
            (entropy - self.target_entropy).detach() * self.log_alpha.exp())
        self.log_alpha_optimizer.zero_grad()
        alpha_loss.backward()
        self.log_alpha_optimizer.step()

        self.soft_update(self.critic_1, self.target_critic_1)
        self.soft_update(self.critic_2, self.target_critic_2)

# 主程序
env_name = 'fractional_order'
env = SIR()
# random.seed(0)
# np.random.seed(0)
# env.seed(0)
# torch.manual_seed(0)


ctrl_buf = np.zeros(n)  # 用来储存控制量的预测值
J = np.zeros(n)

state_dim = env.state_dim
action_dim = env.action_dim
action_bound = 1     # 动作最大值0.75
std_bound = env.std_bound
return_list=[]

actor_lr = 3e-6
critic_lr = 3e-4
alpha_lr = 3e-3
train_episodes = 200
hidden_dim = 128
gamma = 0.99
tau = 0.005  # 软更新参数
buffer_size = 100000
minimal_size = 1000
batch_size = 64
target_entropy = -3
device = torch.device("cuda") if torch.cuda.is_available() else torch.device(
    "cpu")

replay_buffer = rl_utils.ReplayBuffer(buffer_size)
agent = SACContinuous(state_dim, hidden_dim, action_dim, action_bound,
                      actor_lr, critic_lr, alpha_lr, target_entropy, tau,
                      gamma, device)
##训练阶段
print("train")
train_list,mulist1,mulist2,mulist3= rl_utils.train_off_policy_agent(env, agent, train_episodes,
                                              replay_buffer, minimal_size,
                                              batch_size)
for i in range(len(train_list)):
    return_list.append(train_list[i])



episodes_list = list(range(len(return_list)))
time = datetime.now().strftime("%Y%m%d-%H%M%S") 
model_policy=PolicyNetContinuous(state_dim, hidden_dim, action_dim, action_bound)
model_actor1=agent.target_critic_1
model_actor2=agent.target_critic_2
# print(return_list)



plt.plot(episodes_list, return_list)

plt.xlabel('Episodes')
plt.ylabel('Returns')
plt.title('SAC on {IoUT}')
plt.savefig('reward.jpg')
df = pd.DataFrame(return_list)
df.to_excel("return_list——3.xlsx",index=False)
plt.show()



# t = np.linspace(0, 500, 499, endpoint=False)
#
# plt.figure(1)
# plt.xlabel('10T')
# plt.ylabel('α3')
# plt.plot(t, mulist1, label='α3')
# plt.ylim(0, 1)
# plt.savefig('α3.jpg')
# df = pd.DataFrame(mulist1)
# df.to_excel("mulist1——2.xlsx",index=False)
# plt.close()
#
# plt.figure(2)
# plt.xlabel('10T')
# plt.ylabel('θ1')
# plt.plot(t, mulist2, label='θ1')
# plt.ylim(0, 1)
# plt.savefig('θ1.jpg')
# df = pd.DataFrame(mulist2)
# df.to_excel("mulist2——2.xlsx",index=False)
# plt.close()
#
# plt.figure(3)
# plt.xlabel('10T')
# plt.ylabel('β2')
# plt.plot(t, mulist3, label='β2')
# plt.ylim(0, 1)
# plt.savefig('β2.jpg')
# df = pd.DataFrame(mulist3)
# df.to_excel("mulist3——2.xlsx",index=False)
# plt.close()















