import numpy as np
import torch
import gym
from env import *
from PPO import PPO, device
from torch.utils.tensorboard import SummaryWriter
import os, shutil
from datetime import datetime
import pandas as pd
import argparse
import warnings
import matplotlib.pyplot as plt
import random
from parameter import *
warnings.filterwarnings("ignore",category=DeprecationWarning)


def str2bool(v):
    '''transfer str to bool for argparse'''
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'True','true','TRUE', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'False','false','FALSE', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

'''Hyperparameter Setting'''
parser = argparse.ArgumentParser()
parser.add_argument('--EnvIdex', type=int, default=0, help='BWv3, BWHv3, Lch_Cv2, PV0, Humanv4, HCv4')
parser.add_argument('--write', type=str2bool, default=True, help='Use SummaryWriter to record the training')
parser.add_argument('--render', type=str2bool, default=False, help='Render or Not')
parser.add_argument('--Loadmodel', type=str2bool, default=False, help='Load pretrained model or Not')
parser.add_argument('--ModelIdex', type=int, default=400, help='which model to load')

parser.add_argument('--seed', type=int, default=160, help='random seed')
parser.add_argument('--T_horizon', type=int, default=256, help='lenth of long trajectory')
parser.add_argument('--distnum', type=int, default=0, help='0:Beta ; 1:GS_ms  ;  2: GS_m')
parser.add_argument('--Max_train_steps', type=int, default=5e5, help='Max training steps')
parser.add_argument('--save_interval', type=int, default=5e5, help='Model saving interval, in steps.')
parser.add_argument('--eval_interval', type=int, default=200, help='Model evaluating interval, in steps.')

parser.add_argument('--gamma', type=float, default=0.99, help='Discounted Factor')
parser.add_argument('--lambd', type=float, default=0.95, help='GAE Factor')
parser.add_argument('--clip_rate', type=float, default=0.2, help='PPO Clip rate')
parser.add_argument('--K_epochs', type=int, default=10, help='PPO update times')
parser.add_argument('--net_width', type=int, default=150, help='Hidden net width')
parser.add_argument('--a_lr', type=float, default=2e-4, help='Learning rate of actor')
parser.add_argument('--c_lr', type=float, default=3e-4, help='Learning rate of critic')
parser.add_argument('--l2_reg', type=float, default=1e-3, help='L2 regulization coefficient for Critic')
parser.add_argument('--a_optim_batch_size', type=int, default=64, help='lenth of sliced trajectory of actor')
parser.add_argument('--c_optim_batch_size', type=int, default=64, help='lenth of sliced trajectory of critic')
parser.add_argument('--entropy_coef', type=float, default=1e-3, help='Entropy coefficient of Actor')
parser.add_argument('--entropy_coef_decay', type=float, default=0.99, help='Decay rate of entropy_coef')
opt = parser.parse_args()
print('2222222222222222222222222222222222222222',opt)

def Action_adapter(a,max_action):
    return  2*(a-0.5)*max_action

def Reward_adapter(r):

    if r <= -100: r = -1


    return r

def evaluate_policy(env, model, render, steps_per_epoch, max_action, EnvIdex):


    scores = 0
    turns = 1
    for j in range(turns):
        kkkkk1=[];kkkkk2=[];kkkkk3=[];ii=N;env.t=0;s, done, ep_r, steps = env.reset(), False, 0, 0;

        while  (ii):

            a, logprob_a = model.evaluate(s)
            act=a
            s_prime, r, done, info = env.step(a)
            ii-=1;
            kkkkk1.append(a[0])
            kkkkk2.append(a[1])
            kkkkk3.append(a[2])

            ep_r += r
            steps += 1
            s = s_prime
        scores = ep_r
    return scores,kkkkk1,kkkkk2,kkkkk3

def train(env):
    scoremax=-1000000;
    k1max=-100000;
    k2max=-100000;
    k3max=-100000;
    write = opt.write
    render = opt.render
    env_with_Dead = False
    

    eval_env = env
    evnname=env.name
    state_dim = env.state_dim
    action_dim = env.action_dim
    max_action = float(env.action_spacehigh)
    max_steps = env._max_episode_steps
    min_action = env.action_spacelow
    print('Env:',evnname,'  state_dim:',state_dim,'  action_dim:',action_dim,
          ' max_a:',max_action,'  min_a:',min_action, 'max_steps', max_steps)
    T_horizon = opt.T_horizon






    Max_train_steps=200*511
    print('-----------------------------',Max_train_steps)
    save_interval = opt.save_interval
    eval_interval = opt.eval_interval

    random_seed = opt.seed
    print("Random Seed: {}".format(random_seed))
    torch.manual_seed(random_seed)


    np.random.seed(random_seed)









    kwargs = {
        "state_dim": state_dim,
        "action_dim": action_dim,
        "env_with_Dead":env_with_Dead,
        "gamma": opt.gamma,
        "lambd": opt.lambd,
        "clip_rate": opt.clip_rate,
        "K_epochs": opt.K_epochs,
        "net_width": opt.net_width,
        "a_lr": opt.a_lr,
        "c_lr": opt.c_lr,
        "dist": 'Beta',
        "l2_reg": opt.l2_reg,
        "a_optim_batch_size":opt.a_optim_batch_size,
        "c_optim_batch_size": opt.c_optim_batch_size,
        "entropy_coef":opt.entropy_coef,
        "entropy_coef_decay":opt.entropy_coef_decay
    }




    if not os.path.exists('model'): os.mkdir('model')
    model = PPO(**kwargs)
    if opt.Loadmodel: model.load(opt.ModelIdex)

    traj_lenth = 0
    total_steps = 0

    while total_steps <= Max_train_steps:
        print(total_steps)
        env.t=0;s, done, steps, ep_r = env.reset(), False, 0, 0
        '''Interact & train'''
        while not done:
            traj_lenth += 1
            steps += 1

            if render:
                a, logprob_a = model.evaluate(s)
            else:
                a, logprob_a = model.select_action(s)

            act=a
            s_prime, r, done, info = env.step(a)
            r = Reward_adapter(r)


            if done :
                dw = True
                print("ture")
            else:
                dw = False

            model.put_data((s, a, r, s_prime, logprob_a, done, dw))
            s = s_prime
            ep_r += r
            
            if not render:
                if traj_lenth % T_horizon == 0:
                    model.train()
                    traj_lenth = 0


            '''record & log'''





            total_steps=total_steps+1;

            
            '''save model'''
            if total_steps % save_interval==0:
                model.save(total_steps)
        score, kkkkk1, kkkkk2, kkkkk3 = evaluate_policy(env, model, False, max_steps, max_action, 0)

        if score > scoremax:
            k1max = kkkkk1
            k2max = kkkkk2
            k3max = kkkkk3
            scoremax = score
        score11.append(score)
        print('EnvName:', 'SIR', 'seed:', random_seed, 'steps: {}k'.format(int(total_steps / 1000)), 'score:',
              score)
    return k1max,k2max,k3max,score11,scoremax




if __name__ == '__main__':
    mulist01=[]
    mulist02=[]
    mulist03=[]
    score11=[]
    score22=[]
    return_list=[]
    env=SIR()

    print(train)
    mulist01,mulist02,mulist03,train_list,scoremax=train(env)
    for i in range(len(train_list)):
        return_list.append(train_list[i])
    print(scoremax)



    plt.figure(0)
    episodes_list = list(range(len(return_list)))
    plt.plot(episodes_list, return_list)
    plt.xlabel('Episodes')
    plt.ylabel('Returns')
    plt.title('PPO on IoUT,rewards')
    plt.savefig('reward-1')
    df = pd.DataFrame(return_list)
    df.to_excel("return_list——10.xlsx", index=False)
    plt.show()











