from collections import namedtuple
import itertools
from itertools import count
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions.normal import Normal
import numpy as np
import collections
import random
import matplotlib.pyplot as plt
import network
from MASAC import MASAC
from buffer import ReplayBuffer
from model import EnsembleModel,FCLayer,EnsembleDynamicsModel,FakeEnv,Swish
from env import *


class AMBMPO:
    def __init__(self, env, agent, fake_env, env_pool, model_pool,
                 rollout_length, rollout_batch_size, real_ratio, num_episode):

        self.env = env
        self.agent = agent
        self.fake_env = fake_env
        self.env_pool = env_pool
        self.model_pool = model_pool
        self.rollout_length = rollout_length
        self.rollout_batch_size = rollout_batch_size
        self.real_ratio = real_ratio
        self.num_episode = num_episode
        device = torch.device("cuda") if torch.cuda.is_available() else torch.device(
        "cpu")

    def rollout_model(self):
        observations, _, _, _, _ = self.env_pool.sample(
            self.rollout_batch_size)
        for obs in observations:
            for i in range(self.rollout_length):
                action = self.agent.take_action(obs)
                reward, next_obs = self.fake_env.step(obs, action)
                self.model_pool.add(obs, action, reward, next_obs, False)
                obs = next_obs

    def update_agent(self, policy_train_batch_size=64):
        env_batch_size = int(policy_train_batch_size * self.real_ratio)
        model_batch_size = policy_train_batch_size - env_batch_size
        for epoch in range(1):
            env_obs, env_action, env_reward, env_next_obs, env_done = self.env_pool.sample(
                env_batch_size)
            if self.model_pool.size() > 0:
                model_obs, model_action, model_reward, model_next_obs, model_done = self.model_pool.sample(
                    model_batch_size)
                obs = np.concatenate((env_obs, model_obs), axis=0)
                env_action_np = tuple(tensor.detach().cpu().numpy() for tensor in env_action if torch.is_tensor(tensor))
                env_action_np = np.concatenate(env_action_np, axis=0)
                model_action_np = tuple(tensor.detach().cpu().numpy() for tensor in model_action if torch.is_tensor(tensor))
                model_action_np = np.concatenate(model_action_np, axis=0)
                action = np.concatenate((env_action_np, model_action_np), axis=0)
                next_obs = np.concatenate((env_next_obs, model_next_obs),
                                          axis=0)
                env_reward_np = tuple(tensor.detach().cpu().numpy() for tensor in env_reward if torch.is_tensor(tensor))

                model_reward_np = tuple(tensor.detach().cpu().numpy() for tensor in model_reward if torch.is_tensor(tensor))

                reward = np.concatenate((env_reward_np, model_reward_np), axis=0)
                done = np.concatenate((env_done, model_done), axis=0)
            else:
                obs, action, next_obs, reward, done = env_obs, env_action, env_next_obs, env_reward, env_done
            transition_dict = {
                'states': obs,
                'actions': action,
                'next_states': next_obs,
                'rewards': reward,
                'dones': done
            }
            self.agent.update(transition_dict)

    def train_model(self):
        obs, action, reward, next_obs, done = self.env_pool.return_all_samples(
        )
        action_np = tuple(tensor.detach().cpu().numpy() for tensor in action if torch.is_tensor(tensor))
        action_np=np.concatenate(action_np, axis=0)
        inputs = np.concatenate((obs, action_np), axis=-1)
        reward_np = tuple(tensor.detach().cpu().numpy() for tensor in reward if torch.is_tensor(tensor))
        reward_np = np.hstack(reward_np)

        reward = np.array(reward_np)
        labels = np.concatenate(
            (np.reshape(reward, (reward.shape[0], -1)), next_obs - obs),
            axis=-1)
        self.fake_env.model.train(inputs, labels)

    def explore(self):
        obs, done2, episode_return = env.reset(), False, 0
        score = [0 for _ in range(num_agents)]
        step = 0
        done2 = False
        while not done2:
            step+=1
            action = self.agent.take_action(obs)
            next_obs1, reward1, done1 = self.env.step1(action)
            next_obs2, reward2, done2 = self.env.step2(action)
            rewards = [reward1, reward2]

            self.env_pool.add(obs, action[0][0], reward1, next_obs1, done1)
            self.env_pool.add(obs, action[1][0], reward2, next_obs2, done2)
            if reward1 > reward2:
                obs = next_obs1
            else:
                obs = next_obs2
            for i in range(num_agents):
                score[i] += rewards[i]
        scores = max(score)
        return scores

    def train(self):
        return_list = []
        explore_return = self.explore()
        print('episode: 1, return: %d' % explore_return)
        return_list.append(explore_return)
        for i_episode in range(self.num_episode - 1):
            obs, done2, episode_return = self.env.reset(), False, 0
            step = 0
            score = [0 for _ in range(num_agents)]
            while not done2:
                if step % 250 == 0:
                    self.train_model()
                    self.rollout_model()
                action = self.agent.take_action(obs)
                next_obs1, reward1, done1 = self.env.step1(action)
                next_obs2, reward2, done2 = self.env.step2(action)
                rewards = [reward1, reward2]
                self.env_pool.add(obs, action[0][0], reward1, next_obs1, done1)
                self.env_pool.add(obs, action[1][0], reward2, next_obs2, done2)
                if reward1>reward2:
                    obs = next_obs1
                else:
                    obs = next_obs2
                for i in range(num_agents):
                    score[i] += rewards[i]

                self.update_agent()
                step += 1
            score = [x.detach().cpu().numpy() for x in score]
            print(score)
            scores = max(score)
            print(scores)
            return_list.append(scores)

        return return_list



env_name = 'fractional_order'
env = SIR()
random.seed(0)
np.random.seed(0)
env.seed(0)
torch.manual_seed(0)
real_ratio = 0.55
num_episodes = 200
actor_lr = 2e-4
critic_lr = 3e-3
alpha_lr = 3e-3
hidden_dim = 256
gamma = 0.99
tau = 0.005
buffer_size = 10000
target_entropy = -3
model_alpha = 0.01
state_dim = env.state_dim
action_dim = env.action_dim
action_bound = 1
std_bound = env.std_bound
num_agents = 2
rollout_batch_size = 1000
rollout_length = 2
model_pool_size = rollout_batch_size * rollout_length
print(f"\n=============== actor_lr-{actor_lr} ===============")
print(f"\n=============== real_ratio-{real_ratio} ===============")
print(f"\n=============== critic_lr-{critic_lr} ===============")
print(f"\n=============== alpha_lr-{alpha_lr} ===============")
print(f"\n=============== buffer_size-{buffer_size} ===============")
print(f"\n=============== target_entropy-{target_entropy} ===============")
print(f"\n=============== model_alpha-{model_alpha} ===============")
print(f"\n=============== rollout_batch_size-{rollout_batch_size} ===============")
print(f"\n=============== rollout_length-{rollout_length} ===============")
agent = MASAC(state_dim, hidden_dim, action_dim, action_bound, actor_lr,
            critic_lr, alpha_lr, target_entropy, tau, gamma)
model = EnsembleDynamicsModel(state_dim, action_dim, model_alpha)
fake_env = FakeEnv(model)
env_pool = ReplayBuffer(buffer_size)
model_pool = ReplayBuffer(model_pool_size)
ambmpo = AMBMPO(env, agent, fake_env, env_pool, model_pool, rollout_length,
            rollout_batch_size, real_ratio, num_episodes)

return_list = ambmpo.train()

episodes_list = list(range(len(return_list)))
plt.plot(episodes_list, return_list)
plt.xlabel('Episodes')
plt.ylabel('Returns')
plt.title('AMBMPO on {}'.format(env_name))
plt.savefig("reward")
plt.show()