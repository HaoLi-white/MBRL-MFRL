from collections import namedtuple
import itertools
from itertools import count
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions.normal import Normal
import numpy as np
import collections
import random
import matplotlib.pyplot as plt

class SelfAttention(nn.Module):
    def __init__(self, input_dim, num_heads):
        super(SelfAttention, self).__init__()
        self.num_heads = num_heads
        self.head_dim = input_dim // num_heads
        self.fc_q = nn.Linear(input_dim, input_dim)
        self.fc_k = nn.Linear(input_dim, input_dim)
        self.fc_v = nn.Linear(input_dim, input_dim)
        self.fc_o = nn.Linear(input_dim, input_dim)

    def forward(self, x):

        D1, D2, D3= 1, 1, 1
        d_tensor = x.unsqueeze(0)
        tensor = d_tensor.repeat(D1, D2, D3)
        batch_size = tensor.shape[0]
        q = self.fc_q(tensor).view(batch_size, self.num_heads, -1, self.head_dim).permute(0, 2, 1, 3)
        k = self.fc_k(tensor).view(batch_size, self.num_heads, -1, self.head_dim).permute(0, 2, 1, 3)
        v = self.fc_v(tensor).view(batch_size, self.num_heads, -1, self.head_dim).permute(0, 2, 1, 3)

        energy = torch.matmul(q, k.permute(0, 1, 3, 2)) / np.sqrt(self.head_dim)
        attention = torch.nn.functional.softmax(energy, dim=-1)
        tensor = torch.matmul(attention, v).permute(0, 2, 1, 3).contiguous().view(batch_size, -1, x.shape[-1])
        tensor = self.fc_o(tensor)
        return tensor

class PolicyNet(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, action_dim, action_bound):
        super(PolicyNet, self).__init__()
        self.fc1 = torch.nn.Linear(state_dim, hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.fc_mu = torch.nn.Linear(hidden_dim, action_dim)
        self.fc_std = torch.nn.Linear(hidden_dim, action_dim)
        self.selfattention=SelfAttention(state_dim, 1)
        self.action_bound = action_bound

    def forward(self, x):
        x = self.selfattention(x)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        mu = self.fc_mu(x)
        std = F.softplus(self.fc_std(x))+1e-7
        dist = Normal(mu, std)
        normal_sample = dist.rsample()
        log_prob = dist.log_prob(normal_sample)
        action = torch.tanh(normal_sample)
        log_prob = log_prob - torch.log(1 - torch.tanh(action).pow(2) + 1e-7)
        action = action * 0.5 + 0.5
        return action, log_prob


class QValueNet(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, action_dim):
        super(QValueNet, self).__init__()
        self.fc1 = torch.nn.Linear(state_dim + action_dim, hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.fc_out = torch.nn.Linear(hidden_dim, 3)

    def forward(self, x, a):
        a=a.reshape(64, 3)
        cat = torch.cat([x, a], dim=1)
        x = F.relu(self.fc1(cat))
        x = F.relu(self.fc2(x))
        return self.fc_out(x)